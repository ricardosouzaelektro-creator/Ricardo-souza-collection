package com.ricardosouza.collection.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.text.Normalizer
import kotlin.math.max

data class ReleaseResult(
    val id: String,
    val artist: String,
    val title: String,
    val year: String,
    val country: String,
    val label: String,
    val barcode: String,
    val catalogNumber: String,
    val genre: String = "",
    val coverUrl: String? = null,
    val tracks: List<String> = emptyList(),
    val mediaFormat: String = ""
)

class MusicBrainzRepository {
    private val client = OkHttpClient()

    suspend fun search(query: String): List<ReleaseResult> = searchSmart(query)

    /**
     * Busca inteligente para OCR de capas.
     * O OCR normalmente encontra o título mas pode perder o artista ou inserir
     * palavras erradas. Por isso fazemos mais de uma consulta e depois
     * ranqueamos os lançamentos pela semelhança do título.
     */
    suspend fun searchSmart(raw: String): List<ReleaseResult> = withContext(Dispatchers.IO) {
        val original = raw.trim()
        if (original.isBlank()) return@withContext emptyList()

        val normalized = normalize(original)
        val candidates = buildQueryCandidates(normalized)

        val merged = linkedMapOf<String, ReleaseResult>()
        for (q in candidates) {
            val encoded = URLEncoder.encode(q, "UTF-8")
            val results = requestReleases(
                "https://musicbrainz.org/ws/2/release/?query=$encoded&fmt=json&limit=25"
            )
            for (r in results) merged.putIfAbsent(r.id, r)
            if (merged.size >= 80) break
        }

        merged.values
            .map { it to score(it, normalized) }
            .sortedByDescending { it.second }
            .map { it.first }
            .take(20)
    }

    /**
     * OCR de capa é ruidoso. Em vez de pesquisar a frase inteira,
     * criamos várias janelas de palavras e também removemos palavras
     * que normalmente são apenas informação técnica da capa.
     */
    private fun buildQueryCandidates(text: String): LinkedHashSet<String> {
        val stop = setOf(
            "CD", "LP", "VOL", "VOLUME", "ALBUM", "MUSIC", "RECORD", "RECORDS",
            "STEREO", "MONO", "DIGITAL", "WARNER", "SONY", "BMG", "EMI", "UNIVERSAL",
            "POLYGRAM", "SOM", "AO", "DO", "DA", "DE", "DOS", "DAS", "E",
            "THE", "A", "AN", "AND", "OF", "LIVE", "LIMITED", "EDITION"
        )
        val words = text.split(" ").filter { it.length >= 2 && it !in stop }
        val out = linkedSetOf<String>()

        if (words.isNotEmpty()) {
            out.add(words.joinToString(" "))
            // Correções comuns de OCR em capas: O/0, I/1, S/5.
            val corrected = words.map { w ->
                w.replace("0", "O").replace("1", "I").replace("5", "S")
            }
            out.add(corrected.joinToString(" "))
        }
        for (size in minOf(7, words.size) downTo 2) {
            for (i in 0..(words.size - size)) {
                val phrase = words.subList(i, i + size).joinToString(" ")
                if (phrase.length >= 5) {
                    out.add("release:\"$phrase\"")
                    out.add(phrase)
                }
            }
        }
        // Uma consulta simples pelo texto original continua sendo útil quando
        // o OCR conseguiu capturar artista + título.
        out.add(text)
        return out
    }

    private fun score(r: ReleaseResult, fullText: String): Int {
        val title = normalize(r.title)
        val artist = normalize(r.artist)
        val text = normalize(fullText)
        var score = 0

        val titleTokens = title.split(" ").filter { it.length >= 3 }.toSet()
        val textTokens = text.split(" ").filter { it.length >= 3 }.toSet()

        // O título é o sinal mais forte quando o artista não foi lido pelo OCR.
        val overlap = titleTokens.intersect(textTokens).size
        score += overlap * 150

        if (title.isNotBlank() && text.contains(title)) score += 900

        // Procura sequências de 2+ palavras do título dentro do OCR.
        val titleWords = title.split(" ").filter { it.length >= 3 }
        for (n in minOf(5, titleWords.size) downTo 2) {
            for (i in 0..(titleWords.size - n)) {
                val phrase = titleWords.subList(i, i + n).joinToString(" ")
                if (text.contains(phrase)) {
                    score += n * 110
                    break
                }
            }
        }

        // Tolerância a erros pequenos do OCR.
        for (tt in titleTokens) {
            if (textTokens.any {
                    levenshtein(tt, it) <= (if (tt.length >= 7) 2 else 1) &&
                    minOf(tt.length, it.length) >= 4
                }) {
                score += 65
            }
        }

        // O artista ajuda quando aparece, mas não pode derrubar um título correto.
        if (artist.isNotBlank()) {
            val artistOverlap = tokenOverlap(artist, text)
            score += artistOverlap * 70
            // O artista pode vir truncado/errado no OCR (ex.: GUINO -> GUINETO).
            val artistTokens = artist.split(" ").filter { it.length >= 4 }
            val ocrTokens = text.split(" ").filter { it.length >= 4 }
            if (artistTokens.any { at -> ocrTokens.any { ot ->
                    minOf(at.length, ot.length) >= 4 &&
                    levenshtein(at, ot) <= (if (at.length >= 7) 2 else 1)
                } }) {
                score += 260
            }
        }

        // Edições brasileiras recebem apenas um pequeno desempate.
        if (r.country.equals("BR", ignoreCase = true)) score += 20

        return score
    }

    private fun tokenOverlap(a: String, b: String): Int {
        val aa = a.split(" ").filter { it.length >= 3 }.toSet()
        val bb = b.split(" ").filter { it.length >= 3 }.toSet()
        return aa.intersect(bb).size
    }

    private fun levenshtein(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var prev = IntArray(b.length + 1) { it }
        for (i in a.indices) {
            val cur = IntArray(b.length + 1)
            cur[0] = i + 1
            for (j in b.indices) {
                val cost = if (a[i] == b[j]) 0 else 1
                cur[j + 1] = minOf(
                    cur[j] + 1,
                    prev[j + 1] + 1,
                    prev[j] + cost
                )
            }
            prev = cur
        }
        return prev[b.length]
    }

    private fun normalize(value: String): String {
        return Normalizer.normalize(value, Normalizer.Form.NFD)
            .replace("\\p{M}".toRegex(), "")
            .uppercase()
            .replace("[^A-Z0-9 ]".toRegex(), " ")
            .replace("\\s+".toRegex(), " ")
            .trim()
    }

    suspend fun details(id: String): ReleaseResult? = withContext(Dispatchers.IO) {
        val url = "https://musicbrainz.org/ws/2/release/$id?inc=artists+labels+recordings+media+tags&fmt=json"
        val req = Request.Builder().url(url)
            .header("User-Agent", "RicardoSouzaCollection/3.0 (personal collection app)")
            .build()
        client.newCall(req).execute().use { response ->
            if (!response.isSuccessful) return@withContext null
            val r = JSONObject(response.body?.string() ?: return@withContext null)
            parseRelease(r)
        }
    }

    suspend fun searchByBarcode(barcode: String): List<ReleaseResult> {
        val encoded = URLEncoder.encode("barcode:$barcode", "UTF-8")
        return requestReleases("https://musicbrainz.org/ws/2/release/?query=$encoded&fmt=json&limit=25")
    }

    private suspend fun requestReleases(url: String): List<ReleaseResult> = withContext(Dispatchers.IO) {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "RicardoSouzaCollection/3.0 (personal collection app)")
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return@withContext emptyList()
            val json = JSONObject(response.body?.string().orEmpty())
            val releases = json.optJSONArray("releases") ?: return@withContext emptyList()
            buildList {
                for (i in 0 until releases.length()) {
                    val r = releases.optJSONObject(i) ?: continue
                    add(parseRelease(r))
                }
            }
        }
    }

    private fun parseRelease(r: JSONObject): ReleaseResult {
        val ac = r.optJSONArray("artist-credit")
        val artist = ac?.optJSONObject(0)?.optString("name").orEmpty()
        val labels = r.optJSONArray("label-info")
        val label = labels?.optJSONObject(0)?.optJSONObject("label")?.optString("name").orEmpty()
        val cat = labels?.optJSONObject(0)?.optString("catalog-number").orEmpty()
        val tracks = mutableListOf<String>()
        val tags = mutableListOf<String>()
        val tagArray = r.optJSONArray("tags")
        if (tagArray != null) {
            for (ti in 0 until tagArray.length()) {
                val tag = tagArray.optJSONObject(ti)?.optString("name").orEmpty().trim()
                if (tag.isNotBlank()) tags.add(tag)
            }
        }
        val media = r.optJSONArray("media")
        var mediaFormat = ""
        if (media != null) {
            for (mi in 0 until media.length()) {
                val mediaObj = media.optJSONObject(mi) ?: continue
                if (mediaFormat.isBlank()) {
                    val f = mediaObj.optString("format").trim()
                    if (f.equals("CD", true)) mediaFormat = "CD"
                    else if (f.contains("vinyl", true) || f.equals("LP", true) || f.contains("12", true)) mediaFormat = "LP"
                }
                val ts = mediaObj.optJSONArray("tracks") ?: continue
                for (ti in 0 until ts.length()) {
                    val t = ts.optJSONObject(ti) ?: continue
                    val title = t.optString("title")
                    if (title.isNotBlank()) tracks.add("${t.optInt("position", ti + 1)}. $title")
                }
            }
        }
        val id = r.optString("id")
        return ReleaseResult(
            id = id,
            artist = artist,
            title = r.optString("title"),
            year = r.optString("date").take(4),
            country = r.optString("country"),
            label = label,
            barcode = r.optString("barcode"),
            catalogNumber = cat,
            genre = tags.distinct().take(3).joinToString(", "),
            coverUrl = if (id.isNotBlank()) "https://coverartarchive.org/release/$id/front-500" else null,
            tracks = tracks,
            mediaFormat = mediaFormat
        )
    }
}
