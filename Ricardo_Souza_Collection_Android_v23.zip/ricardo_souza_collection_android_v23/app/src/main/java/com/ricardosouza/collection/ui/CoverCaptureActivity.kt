package com.ricardosouza.collection.ui

import android.Manifest
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import java.util.concurrent.Executors

class CoverCaptureActivity : ComponentActivity() {
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var preview: PreviewView
    private lateinit var status: TextView
    private var imageCapture: ImageCapture? = null

    private val cameraPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startCamera()
        else status.text = "Permissão da câmera recusada. Ative a câmera nas configurações do aplicativo."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(15,19,26))
        }
        preview = PreviewView(this)
        root.addView(preview, LinearLayout.LayoutParams(-1, 0, 1f))
        status = TextView(this).apply {
            text = "Enquadre a capa inteira e toque em Fotografar."
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(18,12,18,12)
        }
        root.addView(status)
        val capture = Button(this).apply {
            text = "📷 FOTOGRAFAR CAPA"
            setOnClickListener { takePhoto() }
        }
        root.addView(capture)
        setContentView(root)
        if (checkSelfPermission(Manifest.permission.CAMERA) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else {
            cameraPermission.launch(Manifest.permission.CAMERA)
        }
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val previewUseCase = Preview.Builder().build().also {
                it.surfaceProvider = preview.surfaceProvider
            }
            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .build()
            provider.unbindAll()
            provider.bindToLifecycle(
                this, CameraSelector.DEFAULT_BACK_CAMERA,
                previewUseCase, imageCapture
            )
        }, ContextCompat.getMainExecutor(this))
    }

    private fun takePhoto() {
        val capture = imageCapture ?: return
        val file = File(cacheDir, "cover_${System.currentTimeMillis()}.jpg")
        val options = ImageCapture.OutputFileOptions.Builder(file).build()
        status.text = "Processando a capa..."
        capture.takePicture(
            options,
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onError(exc: ImageCaptureException) {
                    status.text = "Não consegui fotografar. Tente novamente."
                }
                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    recognizeText(Uri.fromFile(file))
                }
            }
        )
    }

    private fun recognizeText(uri: Uri) {
        try {
            val image = InputImage.fromFilePath(this, uri)
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            recognizer.process(image)
                .addOnSuccessListener { result ->
                    val text = result.text.replace(Regex("\\s+"), " ").trim()
                    if (text.isBlank()) {
                        status.text = "Não consegui ler o texto. Tente uma foto mais frontal e iluminada."
                        return@addOnSuccessListener
                    }
                    status.text = "Texto encontrado. Pesquisando..."
                    val i = Intent(this, IdentificationActivity::class.java)
                    i.putExtra("cover_text", text)
                    i.putExtra("cover_uri", uri.toString())
                    startActivity(i)
                }
                .addOnFailureListener {
                    status.text = "Falha ao reconhecer o texto da capa."
                }
        } catch (e: Exception) {
            status.text = "Não consegui abrir a foto."
        }
    }

    override fun onDestroy() {
        executor.shutdown()
        super.onDestroy()
    }
}
