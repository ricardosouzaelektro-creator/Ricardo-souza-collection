# Ricardo Souza Collection — V22

Aplicativo Android para catalogar a coleção pessoal de CDs e LPs.

## Estado desta versão

- Versão do aplicativo: **2.3**
- versionCode: **22**
- Projeto preparado para compilação em **GitHub Actions**.
- O workflow instala Android SDK 35, usa JDK 17 e Gradle 8.9 e gera o APK de debug como artefato.

## Como gerar o APK

1. Coloque este projeto em um repositório GitHub.
2. Faça push para `main` ou `master`, ou abra **Actions → Build Android APK → Run workflow**.
3. Aguarde a conclusão do job.
4. Em **Artifacts**, baixe `ricardo-souza-collection-apk`.
5. O arquivo gerado é um APK Android instalável para testes.

## Importante

O ambiente desta conversa não possui Android SDK/Gradle instalado. Portanto, não foi afirmado que o APK já foi compilado aqui. O workflow acima é o mecanismo preparado para realizar a compilação real.

## Funcionalidades principais

- Cadastro de CDs e LPs
- Identificação pela capa com câmera + OCR
- Leitura de código de barras
- Busca de lançamentos no MusicBrainz
- Confirmação da edição antes de salvar
- Capa armazenada localmente
- Artista, álbum, ano, gênero, gravadora, país, código de barras, número de catálogo, faixas, condição e localização
- Busca e filtros
- Estatísticas da coleção
- Backup e restauração em JSON
- Detecção de possíveis duplicatas

## Compilação real
A V23 inclui um workflow GitHub Actions para gerar o APK sem depender de Gradle/Android SDK instalado localmente. O APK deve ser considerado pronto somente após uma execução verde de `Build Android APK` e download do artefato `ricardo-souza-collection-apk`.
