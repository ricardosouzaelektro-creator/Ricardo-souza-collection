package com.ricardosouza.collection

import android.app.AlertDialog
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.ricardosouza.collection.data.Album
import com.ricardosouza.collection.data.AppDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AddAlbumActivity : AppCompatActivity() {
    private lateinit var artist: EditText
    private lateinit var title: EditText
    private lateinit var year: EditText
    private lateinit var genre: EditText
    private lateinit var label: EditText
    private lateinit var barcode: EditText
    private lateinit var catalog: EditText
    private lateinit var country: EditText
    private lateinit var location: EditText
    private lateinit var condition: Spinner
    private lateinit var format: Spinner

    private fun field(hint: String) = EditText(this).apply {
        this.hint = hint
        setPadding(22, 16, 22, 16)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        artist = field("Artista *")
        title = field("Álbum *")
        year = field("Ano")
        genre = field("Gênero")
        label = field("Gravadora / Selo")
        barcode = field("Código de barras").apply { setText(intent.getStringExtra("barcode").orEmpty()) }
        catalog = field("Número de catálogo")
        country = field("País da edição")
        location = field("Estante / prateleira")

        format = Spinner(this).apply {
            adapter = ArrayAdapter(this@AddAlbumActivity,
                android.R.layout.simple_spinner_dropdown_item, arrayOf("CD", "LP"))
        }
        condition = Spinner(this).apply {
            adapter = ArrayAdapter(this@AddAlbumActivity,
                android.R.layout.simple_spinner_dropdown_item,
                arrayOf("Novo", "Muito bom", "Bom", "Regular", "Ruim"))
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 26, 24, 26)
        }

        root.addView(TextView(this).apply {
            text = "➕ ADICIONAR À COLEÇÃO"
            textSize = 23f
            setPadding(0, 0, 0, 18)
        })

        listOf(
            artist, title, format, year, genre, label, barcode, catalog,
            country, location, condition
        ).forEach(root::addView)

        root.addView(Button(this).apply {
            text = "💾 SALVAR NA COLEÇÃO"
            setOnClickListener { save() }
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun save() {
        val a = artist.text.toString().trim()
        val t = title.text.toString().trim()
        if (a.isBlank() || t.isBlank()) {
            Toast.makeText(this, "Informe artista e álbum.", Toast.LENGTH_SHORT).show()
            return
        }

        val item = Album(
            artist = a,
            title = t,
            format = format.selectedItem.toString(),
            year = year.text.toString().trim().toIntOrNull(),
            genre = genre.text.toString().trim().ifBlank { null },
            label = label.text.toString().trim().ifBlank { null },
            barcode = barcode.text.toString().trim().ifBlank { null },
            catalogNumber = catalog.text.toString().trim().ifBlank { null },
            country = country.text.toString().trim().ifBlank { null },
            location = location.text.toString().trim().ifBlank { null },
            condition = condition.selectedItem.toString()
        )

        lifecycleScope.launch {
            val existing = DuplicateGuard.find(this@AddAlbumActivity, item)
            if (existing != null) {
                AlertDialog.Builder(this@AddAlbumActivity)
                    .setTitle("Item possivelmente duplicado")
                    .setMessage(DuplicateGuard.message(existing))
                    .setNegativeButton("Cancelar", null)
                    .setPositiveButton("Adicionar mesmo assim") { _, _ ->
                        lifecycleScope.launch(Dispatchers.IO) {
                            AppDatabase.get(this@AddAlbumActivity).albumDao().insert(item)
                            withContext(Dispatchers.Main) {
                                Toast.makeText(this@AddAlbumActivity, "Item adicionado.", Toast.LENGTH_SHORT).show()
                                finish()
                            }
                        }
                    }.show()
            } else {
                lifecycleScope.launch(Dispatchers.IO) {
                    AppDatabase.get(this@AddAlbumActivity).albumDao().insert(item)
                    withContext(Dispatchers.Main) {
                        Toast.makeText(this@AddAlbumActivity, "Item adicionado.", Toast.LENGTH_SHORT).show()
                        finish()
                    }
                }
            }
        }
    }
}
