package com.ricardosouza.collection

import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import com.ricardosouza.collection.data.AppDatabase
import com.ricardosouza.collection.data.CollectionBackup
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class BackupActivity : ComponentActivity() {

    private val exportLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) exportTo(uri)
    }

    private val importLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) importFrom(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 30, 24, 24)
        }

        root.addView(TextView(this).apply {
            text = "💾 BACKUP DA COLEÇÃO"
            textSize = 25f
        })

        root.addView(TextView(this).apply {
            text = "Exporte o acervo para um arquivo que você pode guardar em outro local."
            setPadding(0, 12, 0, 22)
        })

        root.addView(Button(this).apply {
            text = "📤 EXPORTAR BACKUP PARA ARQUIVO"
            setOnClickListener {
                exportLauncher.launch("ricardo_souza_collection_backup.json")
            }
        })

        root.addView(Button(this).apply {
            text = "📂 RESTAURAR BACKUP"
            setOnClickListener {
                importLauncher.launch(arrayOf("application/json", "text/json", "application/octet-stream"))
            }
        })

        root.addView(TextView(this).apply {
            text = "\nRecomendação: depois de exportar, guarde o arquivo também no computador ou em uma nuvem."
            setTextColor(android.graphics.Color.GRAY)
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun exportTo(uri: Uri) {
        lifecycleScope.launch(Dispatchers.IO) {
            val json = CollectionBackup.toJson(
                AppDatabase.get(this@BackupActivity).albumDao().allNow()
            )
            contentResolver.openOutputStream(uri)?.use {
                it.write(json.toByteArray(Charsets.UTF_8))
            }
            withContext(Dispatchers.Main) {
                Toast.makeText(
                    this@BackupActivity,
                    "✅ Backup exportado com sucesso.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun importFrom(uri: Uri) {
        lifecycleScope.launch(Dispatchers.IO) {
            val count = CollectionBackup.importJson(this@BackupActivity, uri)
            withContext(Dispatchers.Main) {
                Toast.makeText(
                    this@BackupActivity,
                    "✅ $count item(ns) restaurado(s).",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }
}
