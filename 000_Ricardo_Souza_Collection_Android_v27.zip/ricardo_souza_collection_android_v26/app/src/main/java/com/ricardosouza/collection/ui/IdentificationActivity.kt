package com.ricardosouza.collection.ui

import android.graphics.Color
import android.os.Bundle
import java.io.File
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import com.ricardosouza.collection.data.*
import com.ricardosouza.collection.network.MusicBrainzRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class IdentificationActivity : ComponentActivity() {
    private val repo = MusicBrainzRepository()
    private lateinit var db: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = AppDatabase.get(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 24, 20, 24)
            setBackgroundColor(Color.rgb(15, 19, 26))
        }
        val title = TextView(this).apply {
            text = "💿 Confirmar edição"
            textSize = 22f
            setTextColor(Color.WHITE)
        }
        val query = EditText(this).apply {
            hint = "Artista + álbum"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
        }
        val search = Button(this).apply { text = "🌐 PESQUISAR" }
        val results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        root.addView(title)
        root.addView(query)
        root.addView(search)
        root.addView(results)
        setContentView(ScrollView(this).apply { addView(root) })

        val ocr = intent.getStringExtra("cover_text").orEmpty()
        query.setText(ocr.take(120))
        if (ocr.isNotBlank()) searchResults(ocr, results)
        search.setOnClickListener { searchResults(query.text.toString(), results) }
    }

    private fun searchResults(q: String, results: LinearLayout) {
        results.removeAllViews()
        lifecycleScope.launch {
            val found = repo.search(q)
            results.removeAllViews()
            if (found.isEmpty()) {
                results.addView(TextView(this@IdentificationActivity).apply {
                    text = "Nenhuma edição encontrada."
                    setTextColor(Color.LTGRAY)
                })
                return@launch
            }

            found.forEach { r ->
                val item = LinearLayout(this@IdentificationActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(12, 14, 12, 18)
                }
                item.addView(TextView(this@IdentificationActivity).apply {
                    text = "${r.artist} — ${r.title}"
                    textSize = 17f
                    setTextColor(Color.WHITE)
                })
                item.addView(TextView(this@IdentificationActivity).apply {
                    text = "${r.year} • ${r.country} • ${r.label}\nCódigo: ${r.barcode}\nCatálogo: ${r.catalogNumber}"
                    setTextColor(Color.LTGRAY)
                })
                item.addView(Button(this@IdentificationActivity).apply {
                    text = "USAR ESTA EDIÇÃO"
                    setOnClickListener { loadAndConfirm(r.id) }
                })
                results.addView(item)
            }
        }
    }

    private fun loadAndConfirm(id: String) {
        lifecycleScope.launch {
            val r = repo.details(id) ?: return@launch
            val form = LinearLayout(this@IdentificationActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(20, 24, 20, 24)
                setBackgroundColor(Color.rgb(15, 19, 26))
            }

            fun f(label: String, value: String?) = EditText(this@IdentificationActivity).apply {
                hint = label
                setText(value.orEmpty())
                setTextColor(Color.WHITE)
                setHintTextColor(Color.GRAY)
            }

            val artist = f("Artista", r.artist)
            val title = f("Álbum", r.title)
            val year = f("Ano", r.year)
            val label = f("Gravadora", r.label)
            val barcode = f("Código de barras", r.barcode)
            val cat = f("Número de catálogo", r.catalogNumber)
            val country = f("País da edição", r.country)
            val tracks = f("Faixas", r.tracks.joinToString("\n"))
            val loc = f("Estante / prateleira", "")
            val format = Spinner(this@IdentificationActivity).apply {
                adapter = ArrayAdapter(this@IdentificationActivity, android.R.layout.simple_spinner_dropdown_item, listOf("CD", "LP"))
            }
            val save = Button(this@IdentificationActivity).apply { text = "💾 CONFIRMAR E SALVAR" }

            listOf(artist, title, format, year, label, barcode, cat, country, loc, tracks, save).forEach { form.addView(it) }

            save.setOnClickListener {
                save.isEnabled = false
                lifecycleScope.launch(Dispatchers.IO) {
                    val artistText = artist.text.toString().trim()
                    val titleText = title.text.toString().trim()
                    val localCover = CoverStorage.download(
                        this@IdentificationActivity,
                        r.coverUrl,
                        artistText,
                        titleText
                    )

                    db.albumDao().insert(
                        Album(
                            artist = artistText,
                            title = titleText,
                            format = format.selectedItem.toString(),
                            year = year.text.toString().toIntOrNull(),
                            label = label.text.toString().ifBlank { null },
                            barcode = barcode.text.toString().ifBlank { null },
                            catalogNumber = cat.text.toString().ifBlank { null },
                            country = country.text.toString().ifBlank { null },
                            location = loc.text.toString().ifBlank { null },
                            tracks = tracks.text.toString().ifBlank { null },
                            coverUri = localCover ?: r.coverUrl
                        )
                    )

                    withContext(Dispatchers.Main) {
                        Toast.makeText(
                            this@IdentificationActivity,
                            if (localCover != null) "💿 Álbum salvo com a capa no aparelho!" else "💿 Álbum salvo na coleção!",
                            Toast.LENGTH_LONG
                        ).show()
                        finish()
                    }
                }
            }

            setContentView(ScrollView(this@IdentificationActivity).apply { addView(form) })
        }
    }
}
