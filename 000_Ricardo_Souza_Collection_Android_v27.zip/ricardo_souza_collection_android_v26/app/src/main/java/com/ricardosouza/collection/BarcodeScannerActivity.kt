package com.ricardosouza.collection

import android.Manifest
import android.os.Bundle
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import java.util.concurrent.Executors

class BarcodeScannerActivity : ComponentActivity() {
    private lateinit var preview: PreviewView
    private lateinit var status: TextView
    private val executor = Executors.newSingleThreadExecutor()
    private var scanning = true

    private val permission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startCamera()
        else {
            status.text = "A câmera é necessária para ler o código."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this)
        preview = PreviewView(this)
        root.addView(preview, FrameLayout.LayoutParams(-1, -1))

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 28)
            setBackgroundColor(0xAA000000.toInt())
        }
        status = TextView(this).apply {
            text = "Aponte para o código de barras do CD/LP."
            textSize = 18f
            setTextColor(0xFFFFFFFF.toInt())
        }
        panel.addView(status)
        root.addView(panel, FrameLayout.LayoutParams(-1, -2).apply {
            gravity = android.view.Gravity.TOP
        })

        setContentView(root)

        permission.launch(Manifest.permission.CAMERA)
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()

            val previewUseCase = Preview.Builder().build().also {
                it.surfaceProvider = preview.surfaceProvider
            }

            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()

            val scanner = BarcodeScanning.getClient()
            analysis.setAnalyzer(executor) { proxy ->
                if (!scanning) {
                    proxy.close()
                    return@setAnalyzer
                }

                val media = proxy.image
                if (media == null) {
                    proxy.close()
                    return@setAnalyzer
                }

                val image = InputImage.fromMediaImage(
                    media,
                    proxy.imageInfo.rotationDegrees
                )

                scanner.process(image)
                    .addOnSuccessListener { codes ->
                        val code = codes.firstOrNull()?.rawValue
                        if (!code.isNullOrBlank() && scanning) {
                            scanning = false
                            runOnUiThread {
                                status.text = "Código encontrado: $code"
                                startActivity(
                                    android.content.Intent(
                                        this@BarcodeScannerActivity,
                                        BarcodeResultActivity::class.java
                                    ).putExtra("barcode", code)
                                )
                                finish()
                            }
                        }
                    }
                    .addOnCompleteListener { proxy.close() }
            }

            provider.unbindAll()
            provider.bindToLifecycle(
                this,
                CameraSelector.DEFAULT_BACK_CAMERA,
                previewUseCase,
                analysis
            )
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onDestroy() {
        executor.shutdown()
        super.onDestroy()
    }
}
