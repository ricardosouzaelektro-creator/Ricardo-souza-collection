package com.ricardosouza.collection.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder

data class ReleaseResult(
    val id: String,
    val artist: String,
    val title: String,
    val year: String,
    val country: String,
    val label: String,
    val barcode: String,
    val catalogNumber: String,
    val coverUrl: String? = null,
    val tracks: List<String> = emptyList()
)

class MusicBrainzRepository {
    private val client=OkHttpClient()

    suspend fun search(query:String):List<ReleaseResult> = withContext(Dispatchers.IO) {
        val encoded=URLEncoder.encode(query,"UTF-8")
        val url="https://musicbrainz.org/ws/2/release/?query=$encoded&fmt=json&limit=10"
        val req=Request.Builder().url(url)
            .header("User-Agent","RicardoSouzaCollection/2.2 (personal collection app)")
            .build()
        client.newCall(req).execute().use { response ->
            if(!response.isSuccessful) return@withContext emptyList()
            val root=JSONObject(response.body?.string() ?: return@withContext emptyList())
            val arr=root.optJSONArray("releases") ?: return@withContext emptyList()
            buildList {
                for(i in 0 until arr.length()){
                    val r=arr.getJSONObject(i)
                    val ac=r.optJSONArray("artist-credit")
                    val artist=if(ac!=null&&ac.length()>0) ac.getJSONObject(0).optString("name") else ""
                    val labels=r.optJSONArray("label-info")
                    val label=if(labels!=null&&labels.length()>0) labels.getJSONObject(0).optJSONObject("label")?.optString("name").orEmpty() else ""
                    val cat=if(labels!=null&&labels.length()>0) labels.getJSONObject(0).optString("catalog-number") else ""
                    val id=r.optString("id")
                    add(ReleaseResult(
                        id = id, artist = artist, title = r.optString("title"),
                        year = r.optString("date").take(4), country = r.optString("country"),
                        label = label, barcode = r.optString("barcode"), catalogNumber = cat,
                        coverUrl = "https://coverartarchive.org/release/$id/front-500", tracks = emptyList()
                    ))
                }
            }
        }
    }

    suspend fun details(id:String):ReleaseResult? = withContext(Dispatchers.IO) {
        val url="https://musicbrainz.org/ws/2/release/$id?inc=artists+labels+recordings+media+tags&fmt=json"
        val req=Request.Builder().url(url)
            .header("User-Agent","RicardoSouzaCollection/2.2 (personal collection app)")
            .build()
        client.newCall(req).execute().use { response ->
            if(!response.isSuccessful) return@withContext null
            val r=JSONObject(response.body?.string() ?: return@withContext null)
            val ac=r.optJSONArray("artist-credit")
            val artist=if(ac!=null&&ac.length()>0) ac.getJSONObject(0).optString("name") else ""
            val labels=r.optJSONArray("label-info")
            val label=if(labels!=null&&labels.length()>0) labels.getJSONObject(0).optJSONObject("label")?.optString("name").orEmpty() else ""
            val cat=if(labels!=null&&labels.length()>0) labels.getJSONObject(0).optString("catalog-number") else ""
            val tracks=mutableListOf<String>()
            val media=r.optJSONArray("media")
            if(media!=null) for(i in 0 until media.length()){
                val ts=media.getJSONObject(i).optJSONArray("tracks")
                if(ts!=null) for(j in 0 until ts.length()){
                    val t=ts.getJSONObject(j)
                    tracks.add("${t.optInt("position",j+1)}. ${t.optString("title")}")
                }
            }
            ReleaseResult(r.optString("id"), artist, r.optString("title"), r.optString("date").take(4),
                r.optString("country"), label, r.optString("barcode"), cat,
                "https://coverartarchive.org/release/${r.optString("id")}/front-500", tracks)
        }
    }

    suspend fun searchByBarcode(barcode: String): List<ReleaseResult> {
        val encoded = java.net.URLEncoder.encode("barcode:$barcode", "UTF-8")
        return requestReleases("https://musicbrainz.org/ws/2/release/?query=$encoded&fmt=json&limit=10")
    }

    private suspend fun requestReleases(url: String): List<ReleaseResult> {
        val request = okhttp3.Request.Builder()
            .url(url)
            .header("User-Agent", "RicardoSouzaCollection/2.2 (personal collection app)")
            .build()

        return kotlinx.coroutines.Dispatchers.IO.let { dispatcher ->
            kotlinx.coroutines.withContext(dispatcher) {
                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) return@withContext emptyList()
                    val json = org.json.JSONObject(response.body?.string().orEmpty())
                    val releases = json.optJSONArray("releases") ?: return@withContext emptyList()
                    val out = mutableListOf<ReleaseResult>()
                    for (i in 0 until releases.length()) {
                        val r = releases.optJSONObject(i) ?: continue
                        val artist = r.optJSONArray("artist-credit")
                            ?.optJSONObject(0)?.optJSONObject("artist")?.optString("name").orEmpty()
                        val media = r.optJSONArray("media")
                        val tracks = mutableListOf<String>()
                        if (media != null) {
                            for (mi in 0 until media.length()) {
                                val mt = media.optJSONObject(mi)?.optJSONArray("tracks") ?: continue
                                for (ti in 0 until mt.length()) {
                                    mt.optJSONObject(ti)?.optString("title")?.takeIf { it.isNotBlank() }?.let(tracks::add)
                                }
                            }
                        }
                        out.add(
                            ReleaseResult(
                                id = r.optString("id"),
                                artist = artist,
                                title = r.optString("title"),
                                year = r.optString("date").take(4),
                                country = r.optString("country"),
                                label = "",
                                barcode = r.optString("barcode"),
                                catalogNumber = "",
                                coverUrl = "https://coverartarchive.org/release/${r.optString("id")}/front-500",
                                tracks = tracks
                            )
                        )
                    }
                    out
                }
            }
        }
    }

}
