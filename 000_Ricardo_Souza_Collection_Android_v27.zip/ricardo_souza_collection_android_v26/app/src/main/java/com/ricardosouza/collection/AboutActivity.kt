package com.ricardosouza.collection

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class AboutActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(26, 30, 26, 30)
        }

        root.addView(TextView(this).apply {
            text = "RICARDO SOUZA COLLECTION"
            textSize = 25f
        })
        root.addView(TextView(this).apply {
            text = "\nSeu catálogo pessoal de CDs e LPs.\n\n" +
                    "O aplicativo combina código de barras, leitura de texto da capa e consultas a bancos de dados musicais para encontrar possíveis edições.\n\n" +
                    "Importante: a identificação automática é uma sugestão. Antes de salvar, confira a edição, ano, país e demais dados para evitar cadastrar uma versão errada.\n\n" +
                    "O acervo fica armazenado localmente no aparelho. Use a função de backup regularmente. Ao restaurar um backup, itens já existentes não são duplicados automaticamente."
            textSize = 16f
        })
        root.addView(Button(this).apply {
            text = "FECHAR"
            setOnClickListener { finish() }
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }
}
