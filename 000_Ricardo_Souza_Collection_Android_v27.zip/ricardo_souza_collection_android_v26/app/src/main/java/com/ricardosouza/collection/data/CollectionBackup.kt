package com.ricardosouza.collection.data

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

object CollectionBackup {
    private const val FORMAT = "ricardo_souza_collection"
    private const val VERSION = 1

    fun toJson(items: List<Album>): String {
        val root = JSONObject()
        root.put("format", FORMAT)
        root.put("version", VERSION)
        root.put("createdAt", System.currentTimeMillis())

        val arr = JSONArray()
        items.forEach { a ->
            arr.put(JSONObject().apply {
                put("artist", a.artist)
                put("title", a.title)
                put("format", a.format)
                put("year", a.year ?: JSONObject.NULL)
                put("genre", a.genre ?: JSONObject.NULL)
                put("label", a.label ?: JSONObject.NULL)
                put("barcode", a.barcode ?: JSONObject.NULL)
                put("catalogNumber", a.catalogNumber ?: JSONObject.NULL)
                put("country", a.country ?: JSONObject.NULL)
                put("location", a.location ?: JSONObject.NULL)
                put("condition", a.condition)
                put("coverUri", a.coverUri ?: JSONObject.NULL)
                put("tracks", a.tracks ?: JSONObject.NULL)
                put("createdAt", a.createdAt)
            })
        }
        root.put("items", arr)
        return root.toString(2)
    }

    fun saveBackup(context: Context, json: String) {
        context.openFileOutput("ricardo_souza_collection_backup.json", Context.MODE_PRIVATE).use {
            it.write(json.toByteArray(Charsets.UTF_8))
        }
    }

    suspend fun importJson(context: Context, uri: Uri): Int {
        val text = context.contentResolver.openInputStream(uri)
            ?.bufferedReader()?.use { it.readText() } ?: return 0

        val root = JSONObject(text)
        if (root.optString("format") != FORMAT) return 0
        if (root.optInt("version", -1) != VERSION) return 0

        val array = root.optJSONArray("items") ?: return 0
        var count = 0
        val dao = AppDatabase.get(context).albumDao()

        for (i in 0 until array.length()) {
            val o = array.optJSONObject(i) ?: continue
            val artist = o.optString("artist").trim()
            val title = o.optString("title").trim()
            if (artist.isBlank() || title.isBlank()) continue

            val album = Album(
                artist = artist,
                title = title,
                format = o.optString("format", "CD"),
                year = if (o.isNull("year")) null else o.optInt("year", 0).takeIf { it > 0 },
                genre = o.optString("genre").takeIf { it.isNotBlank() },
                label = o.optString("label").takeIf { it.isNotBlank() },
                barcode = o.optString("barcode").takeIf { it.isNotBlank() },
                catalogNumber = o.optString("catalogNumber").takeIf { it.isNotBlank() },
                country = o.optString("country").takeIf { it.isNotBlank() },
                location = o.optString("location").takeIf { it.isNotBlank() },
                condition = o.optString("condition", "Muito bom"),
                coverUri = o.optString("coverUri").takeIf { it.isNotBlank() },
                tracks = o.optString("tracks").takeIf { it.isNotBlank() },
                createdAt = o.optLong("createdAt", System.currentTimeMillis())
            )

            val duplicate = album.barcode?.let { dao.findByBarcode(it) }
                ?: dao.findSameRelease(album.artist, album.title, album.format)

            if (duplicate == null) {
                dao.insert(album)
                count++
            }
        }
        return count
    }
}
