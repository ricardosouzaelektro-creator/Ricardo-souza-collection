package com.ricardosouza.collection

import android.app.AlertDialog
import android.content.Context
import android.widget.Toast
import com.ricardosouza.collection.data.Album
import com.ricardosouza.collection.data.AppDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object DuplicateGuard {
    suspend fun find(context: Context, album: Album): Album? = withContext(Dispatchers.IO) {
        val dao = AppDatabase.get(context).albumDao()
        val barcode = album.barcode?.trim()
        if (!barcode.isNullOrBlank()) {
            dao.findByBarcode(barcode)?.let { return@withContext it }
        }
        dao.findSameRelease(album.artist.trim(), album.title.trim(), album.format)
    }

    fun message(existing: Album): String =
        "Já existe na coleção:\n\n${existing.artist} — ${existing.title}\n" +
        "${existing.format}${existing.year?.let { " • $it" } ?: ""}" +
        "${existing.location?.let { "\n📍 $it" } ?: ""}"
}
