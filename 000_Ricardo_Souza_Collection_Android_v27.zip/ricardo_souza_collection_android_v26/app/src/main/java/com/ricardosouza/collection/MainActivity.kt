package com.ricardosouza.collection

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import com.ricardosouza.collection.data.*
import com.ricardosouza.collection.ui.CoverCaptureActivity
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.collectLatest

class MainActivity : ComponentActivity() {
    private lateinit var db: AppDatabase
    private lateinit var list: LinearLayout
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val barcodeLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val code = result.data?.getStringExtra("barcode")
        if (!code.isNullOrBlank()) {
            Toast.makeText(this, "Código lido: $code", Toast.LENGTH_SHORT).show()
            searchForBarcode(code)
        }
    }

    private val importLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                val count = withContext(Dispatchers.IO) {
                    CollectionBackup.importJson(this@MainActivity, uri)
                }
                Toast.makeText(this@MainActivity, "$count item(ns) importado(s).", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        db = AppDatabase.get(this)
        home()
    }

    private fun home() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 30, 20, 20)
            setBackgroundColor(Color.rgb(15, 19, 26))
        }

        root.addView(ImageView(this).apply {
            setImageResource(com.ricardosouza.collection.R.drawable.brand_logo)
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            setPadding(8, 8, 8, 18)
        }, LinearLayout.LayoutParams(-1, 280))
        root.addView(TextView(this).apply {
            text = "Seu acervo de CDs e LPs"
            textSize = 16f
            setTextColor(Color.rgb(243,208,138))
            gravity = android.view.Gravity.CENTER
            setPadding(0, 0, 0, 12)
        })

        root.addView(Button(this).apply {
            text = "➕ ADICIONAR MANUALMENTE"
            setOnClickListener {
                startActivity(Intent(this@MainActivity, AddAlbumActivity::class.java))
            }
        })

        root.addView(Button(this).apply {
            text = "📷 LER CÓDIGO DE BARRAS"
            setOnClickListener {
                barcodeLauncher.launch(Intent(this@MainActivity, BarcodeScannerActivity::class.java))
            }
        })

        root.addView(Button(this).apply {
            text = "📷 IDENTIFICAR PELA CAPA"
            setOnClickListener {
                startActivity(Intent(this@MainActivity, CoverCaptureActivity::class.java))
            }
        })

        root.addView(Button(this).apply {
            text = "📚 ABRIR CATÁLOGO"
            setOnClickListener {
                startActivity(Intent(this@MainActivity, CatalogActivity::class.java))
            }
        })

        root.addView(Button(this).apply {
            text = "📊 ESTATÍSTICAS DA COLEÇÃO"
            setOnClickListener {
                startActivity(Intent(this@MainActivity, StatsActivity::class.java))
            }
        })

        val search = EditText(this).apply {
            hint = "🔎 Buscar artista, álbum, gênero, código..."
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
        }
        root.addView(search)

        root.addView(Button(this).apply {
            text = "💾 CRIAR BACKUP"
            setOnClickListener { backup() }
        })

        root.addView(Button(this).apply {
            text = "📂 RESTAURAR BACKUP"
            setOnClickListener {
                importLauncher.launch(arrayOf("application/json", "text/json", "application/octet-stream"))
            }
        })

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list)

        setContentView(ScrollView(this).apply { addView(root) })

        var latestItems = emptyList<com.ricardosouza.collection.data.Album>()
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, b: Int, c: Int, d: Int) {
                val q = s?.toString().orEmpty().lowercase()
                render(latestItems.filter { x ->
                    listOf(
                        x.artist, x.title, x.genre.orEmpty(),
                        x.barcode.orEmpty(), x.location.orEmpty()
                    ).joinToString(" ").lowercase().contains(q)
                })
            }
            override fun afterTextChanged(e: android.text.Editable?) {}
        })

        scope.launch {
            db.albumDao().observeAll().collectLatest { items ->
                latestItems = items
                val q = search.text.toString().lowercase()
                render(items.filter { x ->
                    listOf(
                        x.artist, x.title, x.genre.orEmpty(),
                        x.barcode.orEmpty(), x.location.orEmpty()
                    ).joinToString(" ").lowercase().contains(q)
                })
            }
        }
    }

    private fun render(items: List<Album>) {
        list.removeAllViews()
        list.addView(TextView(this).apply {
            text = "${items.size} itens"
            textSize = 18f
            setTextColor(Color.WHITE)
            setPadding(0, 18, 0, 12)
        })

        items.forEach { a ->
            list.addView(TextView(this).apply {
                text = "💿 ${a.artist} — ${a.title}\n   ${a.format}${a.year?.let { " • $it" } ?: ""}${if (!a.location.isNullOrBlank()) " • 📍 ${a.location}" else ""}"
                textSize = 16f
                setTextColor(Color.WHITE)
                setPadding(8, 16, 8, 16)
                setOnClickListener {
                    startActivity(Intent(this@MainActivity, AlbumDetailActivity::class.java).apply {
                        putExtra("album_id", a.id)
                    })
                }
            })
        }
    }

    private fun searchForBarcode(code: String) {
        scope.launch {
            val items = withContext(Dispatchers.IO) {
                db.albumDao().allNow().filter { it.barcode == code }
            }
            render(items)
            if (items.isEmpty()) {
                Toast.makeText(
                    this@MainActivity,
                    "Nenhum item da coleção possui esse código. Use a identificação pela capa ou adicione manualmente.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun backup() {
        scope.launch(Dispatchers.IO) {
            val json = CollectionBackup.toJson(db.albumDao().allNow())
            CollectionBackup.saveBackup(this@MainActivity, json)
            withContext(Dispatchers.Main) {
                Toast.makeText(this@MainActivity, "Backup salvo no armazenamento do app.", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
