package com.ricardosouza.collection

import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import com.ricardosouza.collection.data.*
import com.ricardosouza.collection.network.MusicBrainzRepository
import kotlinx.coroutines.launch

class BarcodeResultActivity : ComponentActivity() {
    private val repo = MusicBrainzRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val code = intent.getStringExtra("barcode").orEmpty()
        if (code.isBlank()) { finish(); return }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 26, 22, 26)
            setBackgroundColor(Color.rgb(15, 19, 26))
        }
        root.addView(TextView(this).apply {
            text = "🔎 CÓDIGO DE BARRAS\n$code"
            textSize = 21f
            setTextColor(Color.WHITE)
        })
        val status = TextView(this).apply {
            text = "Consultando edições na internet..."
            setTextColor(Color.LTGRAY)
            setPadding(0, 16, 0, 16)
        }
        root.addView(status)
        val results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(results)
        setContentView(ScrollView(this).apply { addView(root) })

        lifecycleScope.launch {
            val candidates = repo.searchByBarcode(code)
            results.removeAllViews()
            if (candidates.isEmpty()) {
                status.text = "Nenhuma edição encontrada. Você pode cadastrar manualmente."
                results.addView(Button(this@BarcodeResultActivity).apply {
                    text = "➕ CADASTRAR MANUALMENTE"
                    setOnClickListener {
                        startActivity(android.content.Intent(this@BarcodeResultActivity, AddAlbumActivity::class.java)
                            .putExtra("barcode", code))
                    }
                })
                return@launch
            }

            status.text = "${candidates.size} possível(is) edição(ões) encontrada(s). Escolha a correta:"
            candidates.forEach { candidate ->
                val box = LinearLayout(this@BarcodeResultActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(8, 12, 8, 18)
                }
                box.addView(TextView(this@BarcodeResultActivity).apply {
                    text = "${candidate.artist} — ${candidate.title}"
                    textSize = 17f
                    setTextColor(Color.WHITE)
                })
                box.addView(TextView(this@BarcodeResultActivity).apply {
                    text = "${candidate.year} • ${candidate.country}\nBarcode: ${candidate.barcode}"
                    setTextColor(Color.LTGRAY)
                })
                box.addView(Button(this@BarcodeResultActivity).apply {
                    text = "USAR ESTA EDIÇÃO"
                    setOnClickListener {
                        startActivity(
                            android.content.Intent(
                                this@BarcodeResultActivity,
                                ReleaseConfirmActivity::class.java
                            ).putExtra("release_id", candidate.id)
                             .putExtra("barcode", code)
                        )
                    }
                })
                results.addView(box)
            }
        }
    }
}
