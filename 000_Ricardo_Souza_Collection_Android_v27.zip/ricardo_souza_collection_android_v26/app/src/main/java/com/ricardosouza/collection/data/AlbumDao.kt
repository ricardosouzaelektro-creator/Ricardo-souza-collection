package com.ricardosouza.collection.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AlbumDao {
    @Query("SELECT * FROM albums ORDER BY artist COLLATE NOCASE, title COLLATE NOCASE")
    fun observeAll(): Flow<List<Album>>

    @Query("""SELECT * FROM albums
        WHERE artist LIKE '%' || :q || '%'
        OR title LIKE '%' || :q || '%'
        OR genre LIKE '%' || :q || '%'
        OR barcode LIKE '%' || :q || '%'
        OR location LIKE '%' || :q || '%'
        ORDER BY artist COLLATE NOCASE, title COLLATE NOCASE""")
    fun search(q: String): Flow<List<Album>>

    @Query("SELECT * FROM albums ORDER BY artist COLLATE NOCASE, title COLLATE NOCASE")
    suspend fun allNow(): List<Album>

    @Query("""SELECT * FROM albums
        WHERE barcode = :barcode
        LIMIT 1""")
    suspend fun findByBarcode(barcode: String): Album?

    @Query("""SELECT * FROM albums
        WHERE lower(artist) = lower(:artist)
        AND lower(title) = lower(:title)
        AND lower(format) = lower(:format)
        LIMIT 1""")
    suspend fun findSameRelease(artist: String, title: String, format: String): Album?

    @Insert
    suspend fun insert(album: Album): Long

    @Update
    suspend fun update(album: Album)

    @Delete
    suspend fun delete(album: Album)
}
