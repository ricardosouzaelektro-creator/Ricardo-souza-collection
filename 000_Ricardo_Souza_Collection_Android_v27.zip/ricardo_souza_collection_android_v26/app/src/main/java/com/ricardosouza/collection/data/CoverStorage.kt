package com.ricardosouza.collection.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File

object CoverStorage {
    private val client = OkHttpClient()

    suspend fun download(context: Context, url: String?, artist: String, title: String): String? =
        withContext(Dispatchers.IO) {
            if (url.isNullOrBlank()) return@withContext null
            try {
                val dir = File(context.filesDir, "covers").apply { mkdirs() }
                val name = "${safe(artist)}_${safe(title)}_${System.currentTimeMillis()}.jpg"
                val file = File(dir, name)
                val request = Request.Builder().url(url).build()
                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) return@withContext null
                    val body = response.body ?: return@withContext null
                    body.byteStream().use { input ->
                        file.outputStream().use { output -> input.copyTo(output) }
                    }
                }
                file.absolutePath
            } catch (_: Exception) {
                null
            }
        }

    private fun safe(value: String): String =
        value.replace(Regex("[^A-Za-z0-9À-ÿ _-]"), "_")
            .replace(Regex("\\s+"), "_")
            .take(60)
}
