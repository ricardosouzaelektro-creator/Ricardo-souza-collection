package com.ricardosouza.collection

import android.app.AlertDialog
import android.os.Bundle
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import com.ricardosouza.collection.data.*
import com.ricardosouza.collection.network.MusicBrainzRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ReleaseConfirmActivity : ComponentActivity() {
    private val repo = MusicBrainzRepository()

    private fun field(h: String, v: String?) = EditText(this).apply {
        hint = h
        setText(v.orEmpty())
        setPadding(20, 14, 20, 14)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getStringExtra("release_id").orEmpty()
        val barcodeFromScan = intent.getStringExtra("barcode")
        if (id.isBlank()) { finish(); return }

        lifecycleScope.launch {
            val r = repo.details(id) ?: run { finish(); return@launch }

            val artist = field("Artista", r.artist)
            val title = field("Álbum", r.title)
            val year = field("Ano", r.year)
            val label = field("Gravadora / Selo", r.label)
            val barcode = field("Código de barras", barcodeFromScan ?: r.barcode)
            val catalog = field("Número de catálogo", r.catalogNumber)
            val country = field("País da edição", r.country)
            val location = field("Estante / prateleira", "")
            val tracks = field("Faixas", r.tracks.joinToString("\n"))
            val format = Spinner(this@ReleaseConfirmActivity).apply {
                adapter = ArrayAdapter(this@ReleaseConfirmActivity,
                    android.R.layout.simple_spinner_dropdown_item, arrayOf("CD", "LP"))
            }

            val root = LinearLayout(this@ReleaseConfirmActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(22, 26, 22, 26)
            }
            root.addView(TextView(this@ReleaseConfirmActivity).apply {
                text = "💿 CONFIRMAR EDIÇÃO"
                textSize = 23f
            })
            listOf(artist, title, format, year, label, barcode, catalog, country, location, tracks).forEach(root::addView)

            root.addView(Button(this@ReleaseConfirmActivity).apply {
                text = "💾 CONFIRMAR E SALVAR"
                setOnClickListener {
                    lifecycleScope.launch(Dispatchers.IO) {
                        val artistText = artist.text.toString().trim()
                        val titleText = title.text.toString().trim()
                        val cover = CoverStorage.download(
                            this@ReleaseConfirmActivity, r.coverUrl, artistText, titleText
                        )
                        val album = Album(
                            artist = artistText,
                            title = titleText,
                            format = format.selectedItem.toString(),
                            year = year.text.toString().trim().toIntOrNull(),
                            label = label.text.toString().trim().ifBlank { null },
                            barcode = barcode.text.toString().trim().ifBlank { null },
                            catalogNumber = catalog.text.toString().trim().ifBlank { null },
                            country = country.text.toString().trim().ifBlank { null },
                            location = location.text.toString().trim().ifBlank { null },
                            tracks = tracks.text.toString().trim().ifBlank { null },
                            coverUri = cover ?: r.coverUrl
                        )
                        val existing = DuplicateGuard.find(this@ReleaseConfirmActivity, album)
                        withContext(Dispatchers.Main) {
                            if (existing != null) {
                                AlertDialog.Builder(this@ReleaseConfirmActivity)
                                    .setTitle("Item possivelmente duplicado")
                                    .setMessage(DuplicateGuard.message(existing))
                                    .setNegativeButton("Cancelar", null)
                                    .setPositiveButton("Adicionar mesmo assim") { _, _ ->
                                        lifecycleScope.launch(Dispatchers.IO) {
                                            AppDatabase.get(this@ReleaseConfirmActivity).albumDao().insert(album)
                                            withContext(Dispatchers.Main) {
                                                Toast.makeText(this@ReleaseConfirmActivity, "💿 Salvo na coleção.", Toast.LENGTH_LONG).show()
                                                finish()
                                            }
                                        }
                                    }.show()
                            } else {
                                lifecycleScope.launch(Dispatchers.IO) {
                                    AppDatabase.get(this@ReleaseConfirmActivity).albumDao().insert(album)
                                    withContext(Dispatchers.Main) {
                                        Toast.makeText(this@ReleaseConfirmActivity, "💿 Salvo na coleção.", Toast.LENGTH_LONG).show()
                                        finish()
                                    }
                                }
                            }
                        }
                    }
                }
            })

            setContentView(ScrollView(this@ReleaseConfirmActivity).apply { addView(root) })
        }
    }
}
