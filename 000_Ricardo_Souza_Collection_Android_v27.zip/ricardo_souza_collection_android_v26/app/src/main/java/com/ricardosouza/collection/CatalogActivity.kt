package com.ricardosouza.collection

import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.ricardosouza.collection.data.AppDatabase
import com.ricardosouza.collection.data.Album
import kotlinx.coroutines.launch

class CatalogActivity : AppCompatActivity() {
    private var allItems = emptyList<Album>()
    private lateinit var grid: GridLayout
    private lateinit var search: EditText
    private lateinit var format: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 20, 16, 16)
            setBackgroundColor(Color.rgb(15, 19, 26))
        }

        root.addView(TextView(this).apply {
            text = "📚 MINHA COLEÇÃO"
            textSize = 24f
            setTextColor(Color.WHITE)
            setPadding(8, 4, 8, 14)
        })

        search = EditText(this).apply {
            hint = "🔎 Artista ou álbum"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
        }
        root.addView(search)

        format = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@CatalogActivity,
                android.R.layout.simple_spinner_dropdown_item,
                arrayOf("Todos", "CD", "LP")
            )
        }
        root.addView(format)

        grid = GridLayout(this).apply {
            columnCount = 2
            useDefaultMargins = true
        }
        root.addView(ScrollView(this).apply {
            addView(grid)
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
        })

        setContentView(root)

        search.addTextChangedListener(SimpleTextWatcher { applyFilter() })
        format.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                applyFilter()
            }
        }

        lifecycleScope.launch {
            AppDatabase.get(this@CatalogActivity).albumDao().observeAll().collect {
                allItems = it
                applyFilter()
            }
        }
    }

    private fun applyFilter() {
        val q = search.text.toString().trim().lowercase()
        val selected = format.selectedItem?.toString() ?: "Todos"
        val filtered = allItems.filter {
            val text = "${it.artist} ${it.title} ${it.genre.orEmpty()}".lowercase()
            (q.isBlank() || text.contains(q)) &&
                (selected == "Todos" || it.format.equals(selected, true))
        }
        render(filtered)
    }

    private fun render(items: List<Album>) {
        grid.removeAllViews()

        items.forEach { album ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(8, 8, 8, 12)
                setBackgroundColor(Color.rgb(27, 32, 42))
                setOnClickListener {
                    startActivity(android.content.Intent(
                        this@CatalogActivity, AlbumDetailActivity::class.java
                    ).putExtra("album_id", album.id))
                }
            }

            val cover = ImageView(this).apply {
                layoutParams = ViewGroup.LayoutParams(360, 360)
                scaleType = ImageView.ScaleType.CENTER_CROP
            }

            val path = album.coverUri
            if (!path.isNullOrBlank() && path.startsWith("/")) {
                BitmapFactory.decodeFile(path)?.let { cover.setImageBitmap(it) }
            }

            card.addView(cover)
            card.addView(TextView(this).apply {
                text = album.title
                textSize = 16f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                setPadding(4, 10, 4, 2)
            })
            card.addView(TextView(this).apply {
                text = "${album.artist}\n${album.format}${album.year?.let { " • $it" } ?: ""}"
                textSize = 13f
                setTextColor(Color.LTGRAY)
                gravity = Gravity.CENTER
                setPadding(4, 0, 4, 6)
            })

            val lp = GridLayout.LayoutParams().apply {
                width = 0
                height = ViewGroup.LayoutParams.WRAP_CONTENT
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(6, 6, 6, 10)
            }
            grid.addView(card, lp)
        }
    }
}

private class SimpleTextWatcher(
    val changed: (String) -> Unit
) : android.text.TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
    override fun onTextChanged(s: CharSequence?, st: Int, before: Int, count: Int) {
        changed(s?.toString().orEmpty())
    }
    override fun afterTextChanged(s: android.text.Editable?) {}
}
