# Gerar o APK do Ricardo Souza Collection

## Caminho automático (recomendado)

Este projeto já possui GitHub Actions configurado em `.github/workflows/android.yml`.

1. Crie um repositório vazio no GitHub chamado `ricardo-souza-collection`.
2. Envie **todo o conteúdo desta pasta** para o repositório, preservando `.github/workflows/android.yml`.
3. Abra a aba **Actions** do repositório.
4. Execute **Build Android APK** usando **Run workflow**.
5. Ao terminar com status verde, abra a execução e baixe o artefato `ricardo-souza-collection-apk`.
6. O arquivo baixado será um APK de debug instalável no Android.

O workflow instala automaticamente JDK 17, Android SDK 35 e usa Gradle 8.9. Não é necessário instalar Android Studio no computador usado para a compilação.

## Se o GitHub Actions apontar erro

Não instale versões aleatórias de Gradle/Kotlin. Copie o erro completo da etapa vermelha da execução. Ele é o dado necessário para corrigirmos o projeto.

## Importante

O APK só deve ser considerado pronto depois de uma execução verde do workflow. Até esse momento, este ZIP é código-fonte, não um APK.
