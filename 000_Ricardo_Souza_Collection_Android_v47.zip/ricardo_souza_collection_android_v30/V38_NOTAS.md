# V38 — Busca externa como fallback

- Mantém a identificação/ranking do MusicBrainz.
- A busca de resumo passa a priorizar primeiro o título exato do álbum junto do artista.
- A tela "Confirmar edição" ganhou "🌐 PESQUISAR NA INTERNET" para casos raros
  em que a base estruturada não possui a edição correta.
- O botão abre uma pesquisa ampla no navegador com artista + álbum + CD, sem
  exigir chave de API.
- VersionCode 38 / versionName 3.8.

Importante: esta é uma melhoria de cobertura, não uma garantia de identificação
automática perfeita. A edição deve continuar sendo confirmada antes de salvar.
