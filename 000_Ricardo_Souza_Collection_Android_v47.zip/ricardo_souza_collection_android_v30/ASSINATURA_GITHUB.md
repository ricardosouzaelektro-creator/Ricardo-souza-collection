# Assinatura fixa do Ricardo Souza Collection

A V30 usa uma chave de assinatura fixa para permitir atualizações sem desinstalar o aplicativo.

No GitHub, crie estes 4 Repository secrets em Settings > Secrets and variables > Actions:

- RSC_KEYSTORE_BASE64 = conteúdo do arquivo `keystore.b64` fornecido junto com esta versão
- RSC_KEYSTORE_PASSWORD = `RSC_2026_Release_Key_9f4c2d7a`
- RSC_KEY_ALIAS = `ricardo-collection`
- RSC_KEY_PASSWORD = `RSC_2026_Release_Key_9f4c2d7a`

Nunca publique o arquivo JKS nem os secrets no repositório.
