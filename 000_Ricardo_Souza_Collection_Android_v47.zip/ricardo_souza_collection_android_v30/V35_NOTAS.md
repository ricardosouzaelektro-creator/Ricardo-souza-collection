# V35 - identificação de capa mais robusta

- Reforçado o peso do título no ranking.
- Frases consecutivas do título recebem pontuação adicional.
- Tolerância maior a erros pequenos do OCR.
- Correções simples de OCR (0/O, 1/I, 5/S).
- Artista ajuda no ranking sem eliminar resultados quando o artista não foi lido.
- Pequeno desempate para edições brasileiras.
- versionCode 35 / versionName 3.5.
