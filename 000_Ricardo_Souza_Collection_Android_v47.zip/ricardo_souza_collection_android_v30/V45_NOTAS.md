# V45 — Preparação do projeto para compilação

- adiciona um ponto de entrada `gradlew` que usa Gradle do ambiente quando disponível;
- documenta o contrato de build;
- não inclui nenhuma chave privada;
- versionCode 45 / versionName 4.5.

Ainda não é APK final.
