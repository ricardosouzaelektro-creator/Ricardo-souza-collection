# V44 — Checklist de migração segura

Antes de qualquer instalação no aparelho principal:
- backup V27 preservado;
- nova versão precisa ter o mesmo applicationId;
- release APK precisa estar assinado com uma chave persistente;
- instalação limpa deve ser testada;
- restauração do backup precisa ser testada;
- capa, resumo, valor e localização precisam sobreviver à restauração;
- somente depois disso o usuário será chamado para trocar de versão.

Não inclui chave privada no projeto público.
VersionCode 44 / versionName 4.4.
