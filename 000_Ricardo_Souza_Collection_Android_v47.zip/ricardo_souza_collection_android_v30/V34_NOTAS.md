# V34 - Identificacao inteligente

- Busca da capa com varias janelas de palavras do OCR.
- Tolerancia a erros de OCR por distancia de Levenshtein.
- Ranking dos candidatos com melhor correspondencia primeiro.
- Resumo automatico via Wikipedia quando disponivel.
- Estimativa automatica via anuncios do Mercado Livre quando houver amostras suficientes.
- Campos de resumo e valor continuam editaveis.
- VersionCode 34 / versionName 3.4.
