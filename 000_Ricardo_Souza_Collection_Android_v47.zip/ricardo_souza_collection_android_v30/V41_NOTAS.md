# V41 — Gênero recuperado da edição

- MusicBrainz agora lê as tags/gêneros da edição quando disponíveis.
- O gênero aparece na confirmação e é gravado no cadastro.
- Isso corrige um ponto que deixava a estatística de gêneros vazia mesmo com releases que tinham tags.
- VersionCode 41 / versionName 4.1.

Ainda é versão de desenvolvimento; não instalar até a etapa de APK estável.
