package com.ricardosouza.collection.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "albums")
data class Album(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val artist: String,
    val title: String,
    val format: String = "CD",
    val year: Int? = null,
    val genre: String? = null,
    val label: String? = null,
    val barcode: String? = null,
    val catalogNumber: String? = null,
    val country: String? = null,
    val location: String? = null,
    val condition: String = "Muito bom",
    val coverUri: String? = null,
    val tracks: String? = null,
    val summary: String? = null,
    val estimatedValue: Double? = null,
    val createdAt: Long = System.currentTimeMillis()
)
