package com.ricardosouza.collection.network

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import kotlin.math.max

data class PriceEstimate(
    val minimum: Double,
    val median: Double,
    val maximum: Double,
    val samples: Int
)

class PriceRepository {
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    /**
     * Estima o valor com base em anúncios atuais do Mercado Livre Brasil.
     * É uma referência de mercado, não um preço garantido de venda.
     */
    suspend fun estimate(artist: String, title: String, format: String): PriceEstimate? {
        val q = URLEncoder.encode("$artist $title $format", "UTF-8")
        val url = "https://api.mercadolibre.com/sites/MLB/search?q=$q&limit=40"
        return try {
            val req = Request.Builder()
                .url(url)
                .header("User-Agent", "RicardoSouzaCollection/3.2")
                .build()

            client.newCall(req).execute().use { response ->
                if (!response.isSuccessful) return null
                val json = JSONObject(response.body?.string().orEmpty())
                val results = json.optJSONArray("results") ?: return null

                val target = normalize("$artist $title")
                val titleTarget = normalize(title)
                val prices = mutableListOf<Double>()

                for (i in 0 until results.length()) {
                    val item = results.optJSONObject(i) ?: continue
                    val itemTitle = item.optString("title")
                    val price = item.optDouble("price", Double.NaN)
                    if (!price.isFinite() || price <= 0.0) continue

                    val similarity = tokenOverlap(normalize(itemTitle), target)
                    val itemNorm = normalize(itemTitle)
                    val titleSimilarity = tokenOverlap(itemNorm, titleTarget)
                    if (similarity >= 2 || titleSimilarity >= 2 || itemNorm.contains(titleTarget)) {
                        prices.add(price)
                    }
                }

                if (prices.size < 3) return null

                prices.sort()
                val low = prices[max(0, (prices.size * 0.20).toInt())]
                val high = prices[minOf(prices.lastIndex, (prices.size * 0.80).toInt())]
                val median = if (prices.size % 2 == 0)
                    (prices[prices.size / 2 - 1] + prices[prices.size / 2]) / 2.0
                else prices[prices.size / 2]

                PriceEstimate(low, median, high, prices.size)
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun normalize(value: String): String =
        java.text.Normalizer.normalize(value, java.text.Normalizer.Form.NFD)
            .replace("\\p{M}+".toRegex(), "")
            .lowercase()
            .replace("[^a-z0-9 ]+".toRegex(), " ")
            .replace("\\s+".toRegex(), " ")
            .trim()

    private fun tokenOverlap(a: String, b: String): Int {
        val aa = a.split(" ").filter { it.length >= 3 }.toSet()
        val bb = b.split(" ").filter { it.length >= 3 }.toSet()
        return aa.intersect(bb).size
    }
}
