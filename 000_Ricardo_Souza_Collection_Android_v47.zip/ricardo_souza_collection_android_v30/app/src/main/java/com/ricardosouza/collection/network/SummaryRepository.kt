package com.ricardosouza.collection.network

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.text.Normalizer
import java.util.concurrent.TimeUnit

class SummaryRepository {
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    /**
     * Busca um resumo curto em fontes públicas. O texto é uma referência
     * editorial e deve ser revisado pelo usuário antes de salvar.
     */
    suspend fun findSummary(artist: String, album: String): String? {
        val candidates = linkedSetOf(
            "\"$album\" \"$artist\"",
            "\"$album\"",
            "$artist $album",
            album
        )

        for (q in candidates) {
            val results = wikipediaSearch(q) ?: continue
            for (i in 0 until results.length()) {
                val item = results.optJSONObject(i) ?: continue
                val title = item.optString("title").trim()
                if (title.isBlank()) continue

                val score = relevance(title, artist, album)
                if (score < 3) continue

                val extract = wikipediaSummary(title) ?: continue
                if (extract.length >= 80) return shorten(extract)
            }
        }
        return null
    }

    private fun wikipediaSearch(query: String): org.json.JSONArray? {
        val q = URLEncoder.encode(query, "UTF-8")
        val url = "https://pt.wikipedia.org/w/api.php?action=query&list=search&srsearch=$q&format=json&utf8=1&srlimit=6"
        val json = get(url) ?: return null
        return json.optJSONObject("query")?.optJSONArray("search")
    }

    private fun wikipediaSummary(title: String): String? {
        val page = URLEncoder.encode(title, "UTF-8")
        val url = "https://pt.wikipedia.org/api/rest_v1/page/summary/$page"
        val obj = get(url) ?: return null
        return obj.optString("extract").trim().takeIf { it.isNotBlank() }
    }

    private fun relevance(pageTitle: String, artist: String, album: String): Int {
        val p = normalize(pageTitle)
        val a = normalize(artist)
        val t = normalize(album)
        var score = 0
        if (t.isNotBlank() && p.contains(t)) score += 4
        score += tokenOverlap(p, t) * 2
        score += tokenOverlap(p, a)
        return score
    }

    private fun get(url: String): JSONObject? = try {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "RicardoSouzaCollection/3.6 (personal collection app)")
            .build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return null
            JSONObject(response.body?.string().orEmpty())
        }
    } catch (_: Exception) { null }

    private fun normalize(value: String): String =
        Normalizer.normalize(value, Normalizer.Form.NFD)
            .replace("\\p{M}+".toRegex(), "")
            .lowercase()
            .replace("[^a-z0-9 ]+".toRegex(), " ")
            .replace("\\s+".toRegex(), " ")
            .trim()

    private fun tokenOverlap(a: String, b: String): Int {
        val aa = a.split(" ").filter { it.length >= 3 }.toSet()
        val bb = b.split(" ").filter { it.length >= 3 }.toSet()
        return aa.intersect(bb).size
    }

    private fun shorten(text: String): String {
        if (text.length <= 420) return text
        val cut = text.substring(0, 420)
        val end = maxOf(cut.lastIndexOf(". "), cut.lastIndexOf("! "), cut.lastIndexOf("? "))
        return if (end > 180) cut.substring(0, end + 1) else cut.trimEnd() + "…"
    }
}
