package com.ricardosouza.collection

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.ricardosouza.collection.data.AppDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class StatsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        lifecycleScope.launch {
            try {
                val albums = withContext(Dispatchers.IO) {
                    AppDatabase.get(this@StatsActivity).albumDao().allNow()
                }
            val cd = albums.count { it.format.equals("CD", true) }
            val lp = albums.count { it.format.equals("LP", true) }
            val cdValue = albums.filter { it.format.equals("CD", true) }.sumOf { it.estimatedValue ?: 0.0 }
            val lpValue = albums.filter { it.format.equals("LP", true) }.sumOf { it.estimatedValue ?: 0.0 }
            val artists = albums.map { it.artist.trim() }.filter { it.isNotBlank() }.distinct().size
            val genres = albums.mapNotNull { it.genre?.trim()?.takeIf(String::isNotBlank) }.distinct().size
            val years = albums.mapNotNull { it.year }.filter { it > 0 }

            val byGenre = albums.mapNotNull { it.genre?.trim()?.takeIf(String::isNotBlank) }
                .groupingBy { it }.eachCount().entries.sortedByDescending { it.value }.take(10)
            val byYear = years.groupingBy { it }.eachCount().entries.sortedByDescending { it.key }.take(10)

            val text = buildString {
                append("📊 ESTATÍSTICAS DA COLEÇÃO\n\n")
                append("Total de itens: ${albums.size}\n")
                append("CDs: $cd\n")
                append("LPs: $lp\n")
                append(String.format(java.util.Locale("pt", "BR"), "Valor estimado dos CDs: R$ %.2f\n", cdValue))
                append(String.format(java.util.Locale("pt", "BR"), "Valor estimado dos LPs: R$ %.2f\n", lpValue))
                append(String.format(java.util.Locale("pt", "BR"), "Valor estimado total: R$ %.2f\n", cdValue + lpValue))
                append("Artistas diferentes: $artists\n")
                append("Gêneros cadastrados: $genres\n")
                if (years.isNotEmpty()) {
                    append("Ano mais antigo: ${years.minOrNull()}\n")
                    append("Ano mais recente: ${years.maxOrNull()}\n")
                }
                if (byGenre.isNotEmpty()) {
                    append("\n🎵 PRINCIPAIS GÊNEROS\n")
                    byGenre.forEach { append("${it.key}: ${it.value}\n") }
                }
                if (byYear.isNotEmpty()) {
                    append("\n📅 ITENS POR ANO\n")
                    byYear.forEach { append("${it.key}: ${it.value}\n") }
                }
            }

                setContentView(ScrollView(this@StatsActivity).apply {
                    addView(TextView(this@StatsActivity).apply {
                        this.text = text
                        textSize = 18f
                        setPadding(28, 28, 28, 28)
                    })
                })
            } catch (e: Exception) {
                setContentView(ScrollView(this@StatsActivity).apply {
                    addView(TextView(this@StatsActivity).apply {
                        text = "Não foi possível carregar as estatísticas agora.\n\nA coleção continua protegida no aparelho."
                        textSize = 18f
                        setPadding(28, 28, 28, 28)
                    })
                })
            }
        }
    }
}
