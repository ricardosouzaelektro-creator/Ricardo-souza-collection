package com.ricardosouza.collection

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.ricardosouza.collection.data.AppDatabase
import com.ricardosouza.collection.ui.CoverCaptureActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class DashboardActivity : AppCompatActivity() {
    private lateinit var total: TextView
    private lateinit var cds: TextView
    private lateinit var lps: TextView
    private lateinit var value: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        build()
    }

    private fun action(text: String, click: () -> Unit) = Button(this).apply {
        this.text = text
        setOnClickListener { click() }
    }

    private fun build() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(Color.rgb(10, 13, 18))
        }

        root.addView(TextView(this).apply {
            text = "RICARDO SOUZA"
            textSize = 28f
            setTextColor(Color.rgb(224, 180, 80))
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "COLLECTION"
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 22)
        })

        val stats = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        total = stat("0", "ITENS")
        cds = stat("0", "CDs")
        lps = stat("0", "LPs")
        value = stat("R$ 0", "VALOR ESTIMADO")
        stats.addView(total); stats.addView(cds); stats.addView(lps)
        root.addView(value)
        root.addView(stats)

        root.addView(action("📚  MINHA COLEÇÃO") {
            startActivity(android.content.Intent(this, CatalogActivity::class.java))
        })
        root.addView(action("📷  IDENTIFICAR PELA CAPA") {
            startActivity(android.content.Intent(this, CoverCaptureActivity::class.java))
        })
        root.addView(action("🔢  LER CÓDIGO DE BARRAS") {
            startActivity(android.content.Intent(this, BarcodeScannerActivity::class.java))
        })
        root.addView(action("➕  ADICIONAR MANUALMENTE") {
            startActivity(android.content.Intent(this, AddAlbumActivity::class.java))
        })
        root.addView(action("📊  ESTATÍSTICAS") {
            startActivity(android.content.Intent(this, StatsActivity::class.java))
        })
        root.addView(action("💾  BACKUP / RESTAURAÇÃO") {
            startActivity(android.content.Intent(this, BackupActivity::class.java))
        })
        root.addView(action("ℹ️  SOBRE O APLICATIVO") {
            startActivity(android.content.Intent(this, AboutActivity::class.java))
        })

        root.addView(TextView(this).apply {
            text = "Uma coleção feita para durar."
            textSize = 13f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setPadding(0, 26, 0, 0)
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun stat(value: String, label: String): TextView =
        TextView(this).apply {
            text = "$value\n$label"
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(24, 14, 24, 20)
        }

    override fun onResume() {
        super.onResume()
        lifecycleScope.launch {
            try {
                val items = withContext(Dispatchers.IO) {
                    AppDatabase.get(this@DashboardActivity).albumDao().allNow()
                }
                total.text = "${items.size}\nITENS"
                cds.text = "${items.count { it.format.equals("CD", true) }}\nCDs"
                lps.text = "${items.count { it.format.equals("LP", true) }}\nLPs"
                val totalValue = items.sumOf { it.estimatedValue ?: 0.0 }
                value.text = String.format(java.util.Locale("pt", "BR"), "R$ %.0f\nVALOR ESTIMADO", totalValue)
            } catch (e: Exception) {
                // A database problem must not prevent the dashboard from opening.
                total.text = "—\nITENS"
                cds.text = "—\nCDs"
                lps.text = "—\nLPs"
                value.text = "—\nVALOR ESTIMADO"
                Toast.makeText(
                    this@DashboardActivity,
                    "A coleção ainda não pôde ser carregada. Você pode abrir o app e tentar novamente.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }
}
