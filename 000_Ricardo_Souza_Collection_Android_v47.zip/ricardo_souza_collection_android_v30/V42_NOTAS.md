# V42 — Backup portátil com capas

Melhoria importante de segurança da coleção:
- o backup continua em JSON;
- passa a incluir, quando disponível, a imagem local da capa;
- restauração cria uma cópia da capa no armazenamento interno do novo app;
- backups antigos V1 continuam aceitos;
- a imagem é limitada a 8 MB por item para evitar arquivos absurdamente grandes;
- metadados continuam sendo restaurados mesmo quando uma capa não puder ser incluída.

VersionCode 42 / versionName 4.2.

Ainda é uma versão de desenvolvimento; não instalar no aparelho principal.
