# V40 — Preparação para versão estável

Objetivo desta etapa:
- manter a identificação por OCR + MusicBrainz;
- manter confirmação manual da edição;
- manter pesquisa externa como fallback;
- manter resumo e valor gravados antes do cadastro;
- manter CD/LP separados nas estatísticas;
- manter backup/restore como proteção da coleção.

Critério para liberar ao usuário:
1. APK compilado sem erros.
2. Assinatura estável definida.
3. Instalação limpa testada.
4. Backup restaurado.
5. Cadastro por câmera testado.
6. Atualização futura usando a mesma chave.

Enquanto esses seis pontos não forem validados, esta versão é de desenvolvimento.
