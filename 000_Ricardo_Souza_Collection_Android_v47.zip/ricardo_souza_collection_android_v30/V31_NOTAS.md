# Ricardo Souza Collection V3.1

## Novidades
- Campo de resumo do álbum, com pesquisa automática em fonte pública (Wikipedia) após identificação.
- Resumo pode ser revisado e editado antes de salvar.
- Campo de valor estimado em reais.
- Estatísticas de valor separadas entre CDs e LPs e total estimado.
- Catálogo continua diferenciando CD e LP.
- Backup/restauração preserva resumo e valor estimado.
- Migração automática do banco da versão 3.0 para 3.1.

## Observação
O valor estimado é um campo de avaliação da coleção. A versão atual não promete preço de venda exato nem substitui uma pesquisa de mercado por edição/condição.
