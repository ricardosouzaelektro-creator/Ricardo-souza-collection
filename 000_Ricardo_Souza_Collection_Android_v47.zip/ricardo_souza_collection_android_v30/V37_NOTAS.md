# V37 — gravação confiável de resumo e valor

Correção importante: quando resumo e valor eram buscados automaticamente durante o salvamento,
a interface podia ser atualizada depois da gravação no Room. Isso fazia o álbum ser salvo sem o
resumo/valor recém-encontrados.

Na V37:
- o resumo automático é resolvido antes do INSERT quando o campo está vazio;
- a estimativa de valor é resolvida antes do INSERT quando o campo está vazio;
- o valor digitado pelo usuário sempre tem prioridade;
- o resumo digitado/editado pelo usuário sempre tem prioridade;
- backup passa a levar esses dados já persistidos no banco;
- a edição por código de barras recebe a mesma proteção.

Não há mudança no banco, portanto não é necessária migração.
