# Build contract

O projeto usa:
- Java 17
- Gradle 8.9
- Android SDK 35
- assembleDebug para o pipeline atual

Para release assinado, a chave deve permanecer fora do repositório público.
O APK final só deve ser entregue depois de validar assinatura, instalação e restauração.
