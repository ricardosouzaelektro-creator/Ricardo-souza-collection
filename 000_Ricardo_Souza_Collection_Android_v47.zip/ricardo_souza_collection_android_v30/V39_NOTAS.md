# V39 — Base de identificação mais segura

- VersionCode 39 / versionName 3.9.
- Mantém a confirmação manual antes de gravar uma edição.
- Mantém busca estruturada e fallback de pesquisa externa.
- Esta versão é tratada como candidata de integração; ainda não deve ser considerada
  a versão final de uso diário até a validação do APK assinado e do fluxo de atualização.
