# V43 — Backup mais identificável

- Backup mantém itens, capas e metadados.
- JSON agora registra quantidade total, CDs e LPs.
- Inclui uma descrição explícita do formato do backup.
- Compatível com a restauração já existente.
- VersionCode 43 / versionName 4.3.

Objetivo: facilitar auditoria e recuperação da coleção antes da migração
para uma instalação estável.
