# V36 - resumos e estimativa mais confiáveis

- Busca de resumo com múltiplas consultas na Wikipédia.
- Ranking de relevância para evitar resumo de página errada.
- Resumo curto e revisável antes de salvar.
- Estimativa de valor com filtro de relevância por título reforçado.
- versionCode 36 / versionName 3.6.
