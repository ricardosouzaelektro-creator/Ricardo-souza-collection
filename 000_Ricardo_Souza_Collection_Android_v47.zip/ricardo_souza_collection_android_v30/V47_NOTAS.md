# V47 — correção de edição e campos nulos

- versionCode 47 / versionName 4.7
- preserva o formato da mídia retornado pela release (CD/LP)
- evita mostrar a string literal `null` na confirmação
- mantém o ID exato da release selecionada
- corrige a expressão de tolerância do OCR

Build/signing continua sendo feito pelo workflow do GitHub Actions.
