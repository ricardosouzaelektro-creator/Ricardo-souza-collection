# Ricardo Souza Collection — V49

Correção do reconhecimento pela capa:
- quando o OCR captura artista + título, o buscador tenta consultas explícitas `artist:"..." AND release:"..."` e `release:"..."`;
- aumenta a quantidade de resultados coletados antes do ranking;
- se houver um título que apareça exatamente no texto OCR, resultados com outro título do mesmo artista não passam à frente;
- mantém as correções da V48 para CD/LP, campos `null` e artista com OCR imperfeito.

Exemplo corrigido: `ALMIR GUINETO SORRISO NOVO` deve priorizar `Sorriso Novo`, em vez de `Almir Guineto` (1986).
