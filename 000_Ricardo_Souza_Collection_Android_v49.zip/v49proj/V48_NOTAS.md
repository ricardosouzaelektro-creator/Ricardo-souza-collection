# V48 — correções de identificação e formato
- elimina a string literal `null` dos campos exibidos na identificação;
- preserva o formato CD/LP quando o MusicBrainz informa a mídia;
- quando a fonte não informa a mídia, não assume CD silenciosamente: mostra `Não informado` para confirmação manual;
- melhora o ranqueamento quando o OCR erra/trunca o nome do artista (ex.: GUINO -> GUINETO);
- mantém a release selecionada pelo ID exato.
