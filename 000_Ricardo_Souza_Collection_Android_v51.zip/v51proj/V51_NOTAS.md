# Ricardo Souza Collection — V51

Correção de metadados para edições históricas que possuem registro incompleto no MusicBrainz.

Caso confirmado: Almir Guineto — Sorriso Novo — Brasil — 1985.
- Formato: LP
- Gravadora: RGE
- Catálogo: 303.6035
- Gênero: Samba, Latin
- Mantém a lista de 12 faixas retornada pela fonte.

A correção só é aplicada quando artista, título, ano e país coincidem exatamente com a edição conhecida; não altera outros discos.
