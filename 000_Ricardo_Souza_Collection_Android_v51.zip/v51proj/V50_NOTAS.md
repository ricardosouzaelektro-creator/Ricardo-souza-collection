# Ricardo Souza Collection — V50

Correção da falha de compilação introduzida na V49 e consolidação das correções da identificação:
- corrige as strings Kotlin das consultas `artist:"..." AND release:"..."` e `release:"..."`;
- mantém a busca explícita por artista + título;
- mantém o ranking que prioriza o título exato encontrado no OCR;
- remove o texto literal `null` dos campos exibidos/salvos;
- preserva CD/LP quando o MusicBrainz informa o formato;
- quando o formato não é informado pela fonte, mostra `Não informado` em vez de assumir CD;
- mantém a tolerância a erros de OCR no nome do artista.

Exemplo-alvo: `ALMIR GUINETO SORRISO NOVO` deve priorizar `Almir Guineto — Sorriso Novo`, em vez de `Almir Guineto — Almir Guineto`.
