package com.ricardosouza.collection

import android.app.AlertDialog
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import com.ricardosouza.collection.data.*
import com.ricardosouza.collection.network.MusicBrainzRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ReleaseConfirmActivity : ComponentActivity() {
    private val repo = MusicBrainzRepository()

    private fun field(h: String, v: String?) = EditText(this).apply {
        hint = h
        setText(v.orEmpty())
        setPadding(20, 14, 20, 14)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getStringExtra("release_id").orEmpty()
        val barcodeFromScan = intent.getStringExtra("barcode")
        if (id.isBlank()) { finish(); return }

        lifecycleScope.launch {
            val r = repo.details(id) ?: run { finish(); return@launch }

            val artist = field("Artista", r.artist)
            val title = field("Álbum", r.title)
            val year = field("Ano", r.year)
            val label = field("Gravadora / Selo", r.label)
            val barcode = field("Código de barras", barcodeFromScan ?: r.barcode)
            val catalog = field("Número de catálogo", r.catalogNumber)
            val country = field("País da edição", r.country)
            val location = field("Estante / prateleira", "")
            val tracks = field("Faixas", r.tracks.joinToString("\n"))
            val summary = field("Resumo do álbum", "")
            summary.minLines = 4
            val estimatedValue = field("Valor estimado (R$)", "")
            val format = Spinner(this@ReleaseConfirmActivity).apply {
                adapter = ArrayAdapter(this@ReleaseConfirmActivity,
                    android.R.layout.simple_spinner_dropdown_item, arrayOf("CD", "LP"))
            }

            val root = LinearLayout(this@ReleaseConfirmActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(22, 26, 22, 26)
            }
            root.addView(TextView(this@ReleaseConfirmActivity).apply {
                text = "💿 CONFIRMAR EDIÇÃO"
                textSize = 23f
            })
            listOf(artist, title, format, year, label, barcode, catalog, country, location, tracks, summary, estimatedValue).forEach(root::addView)

            root.addView(Button(this@ReleaseConfirmActivity).apply {
                text = "🔎 BUSCAR RESUMO"
                setOnClickListener {
                    lifecycleScope.launch {
                        val result = withContext(Dispatchers.IO) { com.ricardosouza.collection.network.SummaryRepository().findSummary(artist.text.toString().trim(), title.text.toString().trim()) }
                        if (result != null) summary.setText(result)
                        else Toast.makeText(this@ReleaseConfirmActivity, "Resumo não encontrado.", Toast.LENGTH_SHORT).show()
                    }
                }
            })

            root.addView(Button(this@ReleaseConfirmActivity).apply {
                text = "🌐 PESQUISAR NA INTERNET"
                setOnClickListener {
                    val q = listOf(
                        artist.text.toString().trim(),
                        title.text.toString().trim()
                    ).filter { it.isNotBlank() }.joinToString(" ")
                    if (q.isNotBlank()) {
                        val url = "https://www.google.com/search?q=" +
                                Uri.encode(q + " CD álbum")
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                    }
                }
            })

            root.addView(Button(this@ReleaseConfirmActivity).apply {
                text = "💰 ESTIMAR VALOR NA INTERNET"
                setOnClickListener {
                    lifecycleScope.launch {
                        val estimate = withContext(Dispatchers.IO) {
                            com.ricardosouza.collection.network.PriceRepository().estimate(
                                artist.text.toString().trim(),
                                title.text.toString().trim(),
                                format.selectedItem?.toString().orEmpty()
                            )
                        }
                        if (estimate == null) {
                            Toast.makeText(this@ReleaseConfirmActivity, "Não encontrei anúncios suficientes para estimar.", Toast.LENGTH_LONG).show()
                        } else {
                            estimatedValue.setText(String.format(java.util.Locale.US, "%.2f", estimate.median))
                            Toast.makeText(
                                this@ReleaseConfirmActivity,
                                String.format(java.util.Locale("pt","BR"), "Estimativa: R$ %.0f–%.0f (%d anúncios). Revise antes de salvar.", estimate.minimum, estimate.maximum, estimate.samples),
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                }
            })

            lifecycleScope.launch {
                val result = withContext(Dispatchers.IO) { com.ricardosouza.collection.network.SummaryRepository().findSummary(r.artist, r.title) }
                if (result != null && summary.text.isBlank()) summary.setText(result)
            }

            root.addView(Button(this@ReleaseConfirmActivity).apply {
                text = "💾 CONFIRMAR E SALVAR"
                setOnClickListener {
                    lifecycleScope.launch(Dispatchers.IO) {
                        val artistText = artist.text.toString().trim()
                        val titleText = title.text.toString().trim()

                        // Se o usuário deixou os campos automáticos vazios, buscamos antes
                        // de gravar para que o resultado realmente faça parte do backup.
                        val finalSummary = summary.text.toString().trim().ifBlank {
                            com.ricardosouza.collection.network.SummaryRepository()
                                .findSummary(artistText, titleText).orEmpty().trim()
                        }.ifBlank { null }

                        val finalValue = estimatedValue.text.toString().trim()
                            .replace(",", ".")
                            .toDoubleOrNull()
                            ?: com.ricardosouza.collection.network.PriceRepository()
                                .estimate(artistText, titleText, format.selectedItem?.toString().orEmpty())
                                ?.median

                        val cover = CoverStorage.download(
                            this@ReleaseConfirmActivity, r.coverUrl, artistText, titleText
                        )
                        val album = Album(
                            artist = artistText,
                            title = titleText,
                            format = format.selectedItem.toString(),
                            year = year.text.toString().trim().toIntOrNull(),
                            label = label.text.toString().trim().ifBlank { null },
                            barcode = barcode.text.toString().trim().ifBlank { null },
                            catalogNumber = catalog.text.toString().trim().ifBlank { null },
                            country = country.text.toString().trim().ifBlank { null },
                            location = location.text.toString().trim().ifBlank { null },
                            tracks = tracks.text.toString().trim().ifBlank { null },
                            summary = finalSummary,
                            estimatedValue = finalValue,
                            coverUri = cover ?: r.coverUrl
                        )
                        val existing = DuplicateGuard.find(this@ReleaseConfirmActivity, album)
                        withContext(Dispatchers.Main) {
                            if (existing != null) {
                                AlertDialog.Builder(this@ReleaseConfirmActivity)
                                    .setTitle("Item possivelmente duplicado")
                                    .setMessage(DuplicateGuard.message(existing))
                                    .setNegativeButton("Cancelar", null)
                                    .setPositiveButton("Adicionar mesmo assim") { _, _ ->
                                        lifecycleScope.launch(Dispatchers.IO) {
                                            AppDatabase.get(this@ReleaseConfirmActivity).albumDao().insert(album)
                                            withContext(Dispatchers.Main) {
                                                Toast.makeText(this@ReleaseConfirmActivity, "💿 Salvo na coleção.", Toast.LENGTH_LONG).show()
                                                finish()
                                            }
                                        }
                                    }.show()
                            } else {
                                lifecycleScope.launch(Dispatchers.IO) {
                                    AppDatabase.get(this@ReleaseConfirmActivity).albumDao().insert(album)
                                    withContext(Dispatchers.Main) {
                                        Toast.makeText(this@ReleaseConfirmActivity, "💿 Salvo na coleção.", Toast.LENGTH_LONG).show()
                                        finish()
                                    }
                                }
                            }
                        }
                    }
                }
            })

            setContentView(ScrollView(this@ReleaseConfirmActivity).apply { addView(root) })
        }
    }
}
