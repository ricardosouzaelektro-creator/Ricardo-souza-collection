package com.ricardosouza.collection

import android.graphics.BitmapFactory
import android.os.Bundle
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.ricardosouza.collection.data.AppDatabase
import com.ricardosouza.collection.data.Album
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AlbumDetailActivity : AppCompatActivity() {
    private lateinit var album: Album
    private lateinit var artist: EditText
    private lateinit var title: EditText
    private lateinit var format: Spinner
    private lateinit var year: EditText
    private lateinit var genre: EditText
    private lateinit var label: EditText
    private lateinit var barcode: EditText
    private lateinit var catalog: EditText
    private lateinit var country: EditText
    private lateinit var location: EditText
    private lateinit var condition: EditText
    private lateinit var tracks: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getLongExtra("album_id", -1L)
        if (id <= 0) { finish(); return }

        lifecycleScope.launch {
            val found = AppDatabase.get(this@AlbumDetailActivity).albumDao().allNow().firstOrNull { it.id == id }
            if (found == null) { finish(); return@launch }
            album = found
            buildUi()
        }
    }

    private fun field(labelText: String, value: String?): EditText =
        EditText(this).apply {
            hint = labelText
            setText(value ?: "")
            setPadding(24, 18, 24, 18)
        }

    private fun buildUi() {
        title = field("Álbum", album.title)
        artist = field("Artista", album.artist)
        year = field("Ano", album.year?.toString())
        genre = field("Gênero", album.genre)
        label = field("Gravadora / Selo", album.label)
        barcode = field("Código de barras", album.barcode)
        catalog = field("Número de catálogo", album.catalogNumber)
        country = field("País da edição", album.country)
        location = field("Localização", album.location)
        condition = field("Condição", album.condition)
        tracks = field("Faixas", album.tracks)
        tracks.minLines = 5

        format = Spinner(this).apply {
            adapter = ArrayAdapter(this@AlbumDetailActivity, android.R.layout.simple_spinner_dropdown_item, arrayOf("CD", "LP"))
            setSelection(if (album.format == "LP") 1 else 0)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }

        root.addView(TextView(this).apply {
            text = "📀 DETALHES DA COLEÇÃO"
            textSize = 24f
            setPadding(0, 0, 0, 20)
        })

        val cover = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                520
            )
        }
        if (!album.coverUri.isNullOrBlank()) {
            val path = album.coverUri!!
            if (path.startsWith("/")) {
                val bitmap = BitmapFactory.decodeFile(path)
                if (bitmap != null) cover.setImageBitmap(bitmap)
            }
        }
        root.addView(cover)
        root.addView(TextView(this).apply {
            text = if (album.coverUri?.startsWith("/") == true) "🖼️ Capa armazenada no aparelho"
                    else "🌐 Capa vinculada pela internet"
            textSize = 13f
        })

        root.addView(artist); root.addView(title); root.addView(format)
        root.addView(year); root.addView(genre); root.addView(label)
        root.addView(barcode); root.addView(catalog); root.addView(country); root.addView(location)
        root.addView(condition); root.addView(tracks)

        root.addView(Button(this).apply {
            text = "💾 SALVAR ALTERAÇÕES"
            setOnClickListener { saveChanges() }
        })

        root.addView(Button(this).apply {
            text = "🗑️ EXCLUIR ITEM"
            setOnClickListener {
                AlertDialog.Builder(this@AlbumDetailActivity)
                    .setTitle("Excluir item?")
                    .setMessage("Este disco será removido da coleção.")
                    .setNegativeButton("Cancelar", null)
                    .setPositiveButton("Excluir") { _, _ ->
                        lifecycleScope.launch {
                            AppDatabase.get(this@AlbumDetailActivity).albumDao().delete(album)
                            finish()
                        }
                    }.show()
            }
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun saveChanges() {
        val updated = album.copy(
            artist = artist.text.toString().trim(),
            title = title.text.toString().trim(),
            format = format.selectedItem.toString(),
            year = year.text.toString().trim().toIntOrNull(),
            genre = genre.text.toString().trim().ifBlank { null },
            label = label.text.toString().trim().ifBlank { null },
            barcode = barcode.text.toString().trim().ifBlank { null },
            catalogNumber = catalog.text.toString().trim().ifBlank { null },
            country = country.text.toString().trim().ifBlank { null },
            location = location.text.toString().trim().ifBlank { null },
            condition = condition.text.toString().trim().ifBlank { "Muito bom" },
            tracks = tracks.text.toString().trim().ifBlank { null }
        )
        lifecycleScope.launch(Dispatchers.IO) {
            AppDatabase.get(this@AlbumDetailActivity).albumDao().update(updated)
            runOnUiThread {
                Toast.makeText(this@AlbumDetailActivity, "Alterações salvas.", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }
}
